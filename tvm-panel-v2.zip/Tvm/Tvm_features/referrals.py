"""Referrals: share a link, friend signs up and buys a plan, both get wallet credit.

Rewards are paid ONCE, after the referred user's first shop purchase (so empty sign-ups earn nothing).
Admin sets the amounts; both default to 0 = programme off until the admin enables it.
"""
import re
import secrets
from datetime import datetime, timedelta

from flask import jsonify, redirect, request, session, url_for

from . import G, db, bad, body, api, admin_api, page, render, now_iso, setting, user, audit, notify, log

ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
CLAIM_WINDOW_DAYS = 3


def _cfg():
    def i(k, d):
        try:
            return max(0, int(setting(k, str(d))))
        except ValueError:
            return d
    return dict(referrer=i('vf_ref_referrer', 0), referred=i('vf_ref_referred', 0), min_price=i('vf_ref_min', 0), cap=i('vf_ref_cap', 50))


def my_code(uid):
    with db() as c:
        r = c.execute('SELECT code FROM vf_ref_codes WHERE user_id=?', (uid,)).fetchone()
        if r:
            return r[0]
        for _ in range(8):
            code = ''.join(secrets.choice(ALPHA) for _ in range(8))
            try:
                c.execute('INSERT INTO vf_ref_codes(user_id,code) VALUES(?,?)', (uid, code))
                return code
            except Exception:
                continue
    raise RuntimeError('could not create referral code')


def claim(uid, code):
    """Link `uid` to the owner of `code`. Returns (ok, message). Never raises."""
    code = re.sub(r'[^A-Za-z0-9]', '', code or '').upper()[:16]
    if not code:
        return False, 'Enter a referral code'
    try:
        with db() as c:
            me = c.execute('SELECT created_at FROM users WHERE id=?', (uid,)).fetchone()
            if not me:
                return False, 'Account not found'
            try:
                age = datetime.now() - datetime.fromisoformat(me['created_at'][:19])
            except Exception:
                age = timedelta(0)
            if age > timedelta(days=CLAIM_WINDOW_DAYS):
                return False, 'Referral codes can only be added in the first %d days after sign-up' % CLAIM_WINDOW_DAYS
            if c.execute('SELECT 1 FROM vf_referrals WHERE referred_id=?', (uid,)).fetchone():
                return False, 'You already used a referral code'
            owner = c.execute('SELECT user_id FROM vf_ref_codes WHERE code=?', (code,)).fetchone()
            if not owner:
                return False, 'That referral code does not exist'
            if owner[0] == uid:
                return False, 'You cannot refer yourself'
            if c.execute('SELECT 1 FROM vps WHERE user_id=?', (uid,)).fetchone() and not setting('vf_ref_allow_existing', ''):
                return False, 'Referral codes are for new accounts without servers'
            c.execute('INSERT INTO vf_referrals(referred_id,referrer_id,status,created_at) VALUES(?,?,?,?)', (uid, owner[0], 'pending', now_iso()))
        return True, 'Referral code applied'
    except Exception as e:
        log.warning('referral claim failed: %s', e)
        return False, 'Could not apply the code'


def on_purchase(uid, price):
    """Called after a successful shop purchase. Pays both sides the first time. Never raises."""
    try:
        from .shop import move, money
        cfg = _cfg()
        if cfg['referrer'] == 0 and cfg['referred'] == 0:
            return
        if price < cfg['min_price']:
            return
        with db() as c:
            r = c.execute("SELECT * FROM vf_referrals WHERE referred_id=? AND status='pending'", (uid,)).fetchone()
            if not r:
                return
            paid = c.execute("SELECT COUNT(*) FROM vf_referrals WHERE referrer_id=? AND status='rewarded'", (r['referrer_id'],)).fetchone()[0]
            give_referrer = cfg['referrer'] if paid < cfg['cap'] else 0
            ok = c.execute("UPDATE vf_referrals SET status='rewarded', reward_referrer=?, reward_referred=?, rewarded_at=? "
                           "WHERE referred_id=? AND status='pending'", (give_referrer, cfg['referred'], now_iso(), uid)).rowcount
            if ok != 1:
                return
            if give_referrer:
                move(c, r['referrer_id'], give_referrer, 'referral', 'Referral reward')
            if cfg['referred']:
                move(c, uid, cfg['referred'], 'referral', 'Welcome bonus (referral)')
        if give_referrer:
            notify(r['referrer_id'], 'success', 'Referral reward', 'A friend you invited bought a plan. %s added to your wallet.' % money(give_referrer))
        if cfg['referred']:
            notify(uid, 'success', 'Welcome bonus', '%s added to your wallet for joining through a referral.' % money(cfg['referred']))
    except Exception as e:
        log.warning('referral reward failed: %s', e)


def install_hooks(app):
    @app.before_request
    def _vf_ref_session():
        try:
            if 'vf_ref' not in session:
                return
            cu = G['current_user']
            if cu.is_authenticated:
                code = session.pop('vf_ref', None)
                claim(cu.id, code)
        except Exception:
            pass


def register(bp):
    @bp.route('/r/<code>')
    def ref_landing(code):
        code = re.sub(r'[^A-Za-z0-9]', '', code).upper()[:16]
        if code:
            session['vf_ref'] = code
        try:
            if G['current_user'].is_authenticated:
                return redirect(url_for('vf.referrals_page'))
        except Exception:
            pass
        return redirect(url_for('register'))

    @bp.route('/referrals')
    @page
    def referrals_page():
        cu = user()
        cfg = _cfg()
        code = my_code(cu.id)
        with db() as c:
            rows = c.execute('SELECT r.*, u.username FROM vf_referrals r JOIN users u ON u.id=r.referred_id '
                             'WHERE r.referrer_id=? ORDER BY r.created_at DESC LIMIT 100', (cu.id,)).fetchall()
            mine = c.execute('SELECT * FROM vf_referrals WHERE referred_id=?', (cu.id,)).fetchone()
            created = c.execute('SELECT created_at FROM users WHERE id=?', (cu.id,)).fetchone()
        earned = sum(r['reward_referrer'] for r in rows)
        try:
            can_claim = not mine and datetime.now() - datetime.fromisoformat(created[0][:19]) <= timedelta(days=CLAIM_WINDOW_DAYS)
        except Exception:
            can_claim = False

        def mask(n):
            return (n[:2] + '***' + n[-1:]) if len(n) > 3 else n[:1] + '***'
        referred = [dict(name=mask(r['username']), status=r['status'], reward=r['reward_referrer'], when=r['created_at'][:10]) for r in rows]
        link = request.url_root.rstrip('/') + '/r/' + code
        return render('features/referrals.html', code=code, link=link, cfg=cfg, referred=referred, earned=earned,
                      pending=sum(1 for r in rows if r['status'] == 'pending'), can_claim=can_claim, mine=bool(mine))

    @bp.route('/features/api/referrals/claim', methods=['POST'])
    @api
    def ref_claim():
        ok, msg = claim(user().id, str(body().get('code') or ''))
        if not ok:
            bad(msg)
        return jsonify(success=True, message=msg)

    @bp.route('/features/api/admin/ref-settings', methods=['POST'])
    @admin_api
    def ref_settings():
        from .shop import to_cents
        d = body()
        G['set_setting']('vf_ref_referrer', str(to_cents(d.get('referrer') or 0)))
        G['set_setting']('vf_ref_referred', str(to_cents(d.get('referred') or 0)))
        G['set_setting']('vf_ref_min', str(to_cents(d.get('min_price') or 0)))
        try:
            cap = max(1, min(100000, int(d.get('cap') or 50)))
        except (TypeError, ValueError):
            bad('Cap must be a number')
        G['set_setting']('vf_ref_cap', str(cap))
        return jsonify(success=True)
