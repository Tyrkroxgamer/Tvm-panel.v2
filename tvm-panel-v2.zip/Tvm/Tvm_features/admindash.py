"""Admin overview: revenue, sign-ups, plan sales, node load, support backlog, referral settings."""
import json
import time
from datetime import datetime, timedelta

from flask import jsonify, request

from . import G, db, admin_page, admin_api, render, setting, now_iso


def _days(n):
    today = datetime.now().date()
    return [(today - timedelta(days=i)).isoformat() for i in range(n - 1, -1, -1)]


def overview(days=30):
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec='seconds')
    labels = _days(days)
    out = {'labels': labels}
    with db() as c:
        def by_day(sql, args=()):
            m = {}
            for r in c.execute(sql, args):
                m[r[0]] = r[1]
            return [m.get(d, 0) for d in labels]
        out['revenue'] = by_day("SELECT substr(created_at,1,10), SUM(price) FROM vf_orders WHERE status IN ('paid','provisioned') "
                                "AND created_at>=? GROUP BY 1", (since,))
        out['credits'] = by_day("SELECT substr(created_at,1,10), SUM(amount) FROM vf_wallet_tx WHERE kind IN ('admin','redeem') "
                                "AND amount>0 AND created_at>=? GROUP BY 1", (since,))
        out['signups'] = by_day('SELECT substr(created_at,1,10), COUNT(*) FROM users WHERE created_at>=? GROUP BY 1', (since,))
        one = lambda sql, a=(): (c.execute(sql, a).fetchone() or [0])[0] or 0
        out['totals'] = dict(
            users=one('SELECT COUNT(*) FROM users'),
            new_users=sum(out['signups']),
            vps=one('SELECT COUNT(*) FROM vps'),
            running=one("SELECT COUNT(*) FROM vps WHERE status='running'"),
            suspended=one('SELECT COUNT(*) FROM vps WHERE suspended=1'),
            revenue=sum(out['revenue']),
            revenue_all=one("SELECT SUM(price) FROM vf_orders WHERE status IN ('paid','provisioned')"),
            held=one('SELECT SUM(balance) FROM vf_wallet'),
            orders=one("SELECT COUNT(*) FROM vf_orders WHERE status IN ('paid','provisioned') AND created_at>=?", (since,)),
            open_tickets=one("SELECT COUNT(*) FROM vf_tickets WHERE status='open'"),
            referrals=one("SELECT COUNT(*) FROM vf_referrals WHERE status='rewarded'"),
            teams=one('SELECT COUNT(*) FROM vf_teams'),
        )
        out['plans'] = [dict(name=r[0] or 'deleted plan', n=r[1], total=r[2] or 0) for r in c.execute(
            "SELECT p.name, COUNT(*), SUM(o.price) FROM vf_orders o LEFT JOIN vf_plans p ON p.id=o.plan_id "
            "WHERE o.status IN ('paid','provisioned') AND o.created_at>=? GROUP BY o.plan_id ORDER BY 2 DESC LIMIT 8", (since,))]
        hour_ago = int(time.time()) - 3600
        loads = {r[0]: (r[1], r[2]) for r in c.execute(
            'SELECT v.node_id, AVG(s.cpu), AVG(s.ram) FROM vf_samples s JOIN vps v ON v.id=s.vps_id '
            'WHERE s.ts>=? AND s.up=1 GROUP BY v.node_id', (hour_ago,))}
        counts = {r[0]: (r[1], r[2]) for r in c.execute(
            "SELECT node_id, COUNT(*), SUM(CASE WHEN status='running' THEN 1 ELSE 0 END) FROM vps GROUP BY node_id")}
    nodes = []
    try:
        for n in G['get_nodes']():
            cnt = counts.get(n['id'], (0, 0))
            ld = loads.get(n['id'], (None, None))
            nodes.append(dict(id=n['id'], name=n['name'], location=n.get('location') or '', status=n.get('status') or 'unknown',
                              vps=cnt[0], running=cnt[1] or 0, slots=n.get('total_vps') or 0,
                              cpu=None if ld[0] is None else round(ld[0]), ram=None if ld[1] is None else round(ld[1])))
    except Exception:
        pass
    out['nodes'] = nodes
    return out


def register(bp):
    @bp.route('/admin/overview')
    @admin_page
    def admin_overview():
        from .referrals import _cfg
        cfg = _cfg()
        return render('features/admin_overview.html', ref=cfg, data=overview(30))

    @bp.route('/features/api/admin/overview')
    @admin_api
    def admin_overview_api():
        try:
            days = max(7, min(90, int(request.args.get('days', 30))))
        except ValueError:
            days = 30
        return jsonify(success=True, **overview(days))
