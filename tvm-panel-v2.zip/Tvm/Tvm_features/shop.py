"""Shop: VPS plans, wallet (balance in cents), redeem codes, orders, renewals.
No payment gateway: admins credit balances or hand out redeem codes."""
import re
import secrets
import threading
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

from flask import jsonify, request

from . import G, db, bad, body, api, admin_api, page, admin_page, render, now_iso, setting, user, audit, notify, log

HOST_RE = re.compile(r'^[a-z][a-z0-9-]{0,40}$')


def to_cents(v, allow_zero=True):
    try:
        d = Decimal(str(v).strip().replace(',', '.'))
    except (InvalidOperation, AttributeError):
        bad('Enter a valid amount')
    if d != d.quantize(Decimal('0.01')) or abs(d) > Decimal('1000000'):
        bad('Amount can have at most 2 decimals and must be under 1,000,000')
    c = int(d * 100)
    if c < 0 or (c == 0 and not allow_zero):
        bad('Amount must be positive')
    return c


def money(c, cur=None):
    cur = cur if cur is not None else setting('vf_currency', '$')
    c = int(c or 0)
    s = '-' if c < 0 else ''
    return '%s%s%d.%02d' % (s, cur, abs(c) // 100, abs(c) % 100)


# ----------------------------------------------------------------------------- wallet core
def balance(uid):
    with db() as c:
        r = c.execute('SELECT balance FROM vf_wallet WHERE user_id=?', (uid,)).fetchone()
    return r[0] if r else 0


def move(c, uid, amount, kind, note=''):
    """Atomically add (+) or remove (-) money inside connection `c`. Raises _Bad when funds are short."""
    c.execute('INSERT OR IGNORE INTO vf_wallet(user_id,balance) VALUES(?,0)', (uid,))
    cur = c.execute('UPDATE vf_wallet SET balance=balance+? WHERE user_id=? AND balance+?>=0', (amount, uid, amount))
    if cur.rowcount != 1:
        bad('Not enough balance. Add funds or redeem a code on the Wallet page.', 402)
    after = c.execute('SELECT balance FROM vf_wallet WHERE user_id=?', (uid,)).fetchone()[0]
    c.execute('INSERT INTO vf_wallet_tx(user_id,amount,kind,note,balance_after,created_at) VALUES(?,?,?,?,?,?)',
              (uid, amount, kind, note[:200], after, now_iso()))
    return after


def _shop_on():
    return setting('vf_shop_enabled', '1') == '1'


# ----------------------------------------------------------------------------- provisioning
def pick_node(plan):
    nodes = G['get_nodes']()
    cands = []
    for n in nodes:
        if plan['node_id'] and n['id'] != plan['node_id']:
            continue
        if str(n.get('status', '')).lower() == 'offline':
            continue
        used = G['get_current_vps_count'](n['id'])
        if used < (n.get('total_vps') or 0):
            cands.append((used / max(1, n['total_vps']), n['id']))
    if not cands:
        bad('No server has free capacity right now. You were not charged.', 409)
    return sorted(cands)[0][1]


def provision(uid, plan, hostname, os_version, node_id):
    """Create the VPS record + start the installer thread (same path as the admin create route)."""
    vps_count = len(G['get_vps_for_user'](uid)) + 1
    name = hostname or 'avm-vps-%d-%d' % (uid, vps_count)
    ram_mb = plan['ram_gb'] * 1024
    config = '%dGB RAM / %d CPU / %dGB Disk / Swap: DISABLED' % (plan['ram_gb'], plan['cpu'], plan['disk_gb'])
    vps_id = G['create_vps'](user_id=uid, node_id=node_id, container_name=name, hostname=name, ram='%dGB' % plan['ram_gb'],
                             cpu=str(plan['cpu']), storage='%dGB' % plan['disk_gb'], config=config, os_version=os_version,
                             expiration_days=plan['period_days'], auto_suspend_enabled=plan['period_days'] > 0,
                             bandwidth_quota_gb=plan['bandwidth_gb'] or 0, swap=0, kvm_enabled=False, status='installing',
                             snapshot_limit=5)

    def run():
        import asyncio
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(G['install_vps_async'](vps_id, name, node_id, ram_mb, plan['cpu'], plan['disk_gb'], os_version,
                                                           None, plan['bandwidth_gb'] or 0, 0, False))
            loop.close()
        except Exception as e:
            log.error('shop install failed: %s', e, exc_info=True)
    threading.Thread(target=run, daemon=True).start()
    return vps_id, name


def _plan(pid, enabled_only=True):
    with db() as c:
        r = c.execute('SELECT * FROM vf_plans WHERE id=?', (pid,)).fetchone()
    if not r or (enabled_only and not r['enabled']):
        bad('Plan not found', 404)
    return dict(r)


def _stock_left(c, plan):
    if plan['stock'] is None:
        return None
    sold = c.execute("SELECT COUNT(*) FROM vf_orders WHERE plan_id=? AND kind='new' AND status IN ('paid','provisioned')", (plan['id'],)).fetchone()[0]
    return max(0, plan['stock'] - sold)


# --------------------------------------------------------------------------------- routes
def register(bp):
    bp.add_app_template_filter(money, 'vf_money')

    # ------------------------------ user pages
    @bp.route('/shop')
    @page
    def shop_page():
        cu = user()
        with db() as c:
            plans = []
            for r in c.execute('SELECT * FROM vf_plans WHERE enabled=1 ORDER BY sort, price'):
                p = dict(r)
                p['left'] = _stock_left(c, p)
                plans.append(p)
        os_list = [{'value': o['value'], 'label': o['label'], 'category': o.get('category', ''), 'min_disk': o.get('min_disk_gb', 0), 'min_ram': o.get('min_ram_mb', 0)}
                   for o in G['OS_OPTIONS']]
        return render('features/shop.html', plans=plans, os_list=os_list, balance=balance(cu.id), shop_on=_shop_on())

    @bp.route('/wallet')
    @page
    def wallet_page():
        cu = user()
        with db() as c:
            tx = [dict(r) for r in c.execute('SELECT * FROM vf_wallet_tx WHERE user_id=? ORDER BY id DESC LIMIT 40', (cu.id,))]
            orders = [dict(r) for r in c.execute('SELECT o.*, p.name plan_name FROM vf_orders o LEFT JOIN vf_plans p ON p.id=o.plan_id '
                                                 'WHERE o.user_id=? ORDER BY o.id DESC LIMIT 20', (cu.id,))]
            owned = [dict(r) for r in c.execute('SELECT vp.vps_id, vp.price, vp.period_days, p.name plan_name FROM vf_vps_plan vp '
                                                'JOIN vps v ON v.id=vp.vps_id LEFT JOIN vf_plans p ON p.id=vp.plan_id WHERE v.user_id=?', (cu.id,))]
        for o in owned:
            v = G['get_vps_by_id'](o['vps_id']) or {}
            o['name'] = v.get('hostname') or v.get('container_name') or 'VPS #%s' % o['vps_id']
            o['expires_at'] = (v.get('expires_at') or '')[:16].replace('T', ' ')
        with db() as c:
            topups = [dict(r) for r in c.execute('SELECT * FROM vf_topups WHERE user_id=? ORDER BY id DESC LIMIT 15', (cu.id,))]
        try:
            topup_min = int(setting('vf_topup_min', '100'))
        except ValueError:
            topup_min = 100
        return render('features/wallet.html', balance=balance(cu.id), tx=tx, orders=orders, owned=owned, topups=topups,
                      pay_info=setting('vf_pay_info', ''), topup_min=topup_min)

    # ------------------------------ user API
    @bp.route('/features/api/shop/buy', methods=['POST'])
    @api
    def shop_buy():
        cu = user()
        if not _shop_on():
            bad('The shop is closed right now', 403)
        d = body()
        plan = _plan(int(d.get('plan_id') or 0))
        os_version = d.get('os') or 'ubuntu:22.04'
        osd = next((o for o in G['OS_OPTIONS'] if o['value'] == os_version), None)
        if not osd:
            bad('Choose a valid operating system')
        if osd.get('min_disk_gb', 0) > plan['disk_gb'] or osd.get('min_ram_mb', 0) > plan['ram_gb'] * 1024:
            bad('This plan is too small for %s' % osd['label'])
        hostname = (d.get('hostname') or '').strip().lower()
        if hostname and not HOST_RE.match(hostname):
            bad('Server name: lowercase letters, digits and dashes, starting with a letter (max 41)')
        if len(G['get_vps_for_user'](cu.id)) >= int(setting('max_vps_per_user', '10')):
            bad('You reached your VPS limit')
        with db() as c:
            if _stock_left(c, plan) == 0:
                bad('This plan is sold out', 409)
            if hostname and c.execute('SELECT 1 FROM vps WHERE container_name=?', (hostname,)).fetchone():
                bad('That server name is taken', 409)
        node_id = pick_node(plan)
        if hostname:
            try:
                if G['run_sync'](G['container_exists'](hostname, node_id)):
                    bad('That server name already exists on the node', 409)
            except Exception as e:
                if getattr(e, 'code', None):
                    raise
        with db() as c:                                           # charge first, atomically
            move(c, cu.id, -plan['price'], 'purchase', 'Plan: %s' % plan['name'])
            oid = c.execute('INSERT INTO vf_orders(user_id,plan_id,price,kind,status,hostname,created_at) VALUES(?,?,?,?,?,?,?)',
                            (cu.id, plan['id'], plan['price'], 'new', 'paid', hostname, now_iso())).lastrowid
        try:
            vps_id, name = provision(cu.id, plan, hostname, os_version, node_id)
        except Exception as e:
            log.error('provision failed: %s', e, exc_info=True)
            with db() as c:
                move(c, cu.id, plan['price'], 'refund', 'Auto refund: could not create server')
                c.execute("UPDATE vf_orders SET status='failed', note=? WHERE id=?", (str(e)[:200], oid))
            bad('Could not create the server, you were refunded: %s' % str(e)[:150], 500)
        with db() as c:
            c.execute("UPDATE vf_orders SET status='provisioned', vps_id=? WHERE id=?", (vps_id, oid))
            c.execute('INSERT OR REPLACE INTO vf_vps_plan(vps_id,plan_id,price,period_days) VALUES(?,?,?,?)',
                      (vps_id, plan['id'], plan['price'], plan['period_days']))
        audit(cu.id, 'shop_purchase', 'vps', vps_id, {'plan': plan['name'], 'price': plan['price']})
        try:
            from . import referrals
            referrals.on_purchase(cu.id, plan['price'])
        except Exception:
            pass
        notify(cu.id, 'success', 'Order placed', '%s is being installed (%s).' % (name, plan['name']))
        return jsonify(success=True, vps_id=vps_id, balance=balance(cu.id))

    @bp.route('/features/api/shop/renew', methods=['POST'])
    @api
    def shop_renew():
        cu = user()
        vps_id = int(body().get('vps_id') or 0)
        vps = G['get_vps_by_id'](vps_id)
        if not vps or vps['user_id'] != cu.id:
            bad('VPS not found', 404)
        with db() as c:
            vp = c.execute('SELECT * FROM vf_vps_plan WHERE vps_id=?', (vps_id,)).fetchone()
        if not vp or vp['period_days'] <= 0:
            bad('This VPS was not bought from the shop, so it cannot be renewed here')
        with db() as c:
            move(c, cu.id, -vp['price'], 'renewal', 'Renew VPS #%d' % vps_id)
            c.execute('INSERT INTO vf_orders(user_id,plan_id,vps_id,price,kind,status,created_at) VALUES(?,?,?,?,?,?,?)',
                      (cu.id, vp['plan_id'], vps_id, vp['price'], 'renew', 'paid', now_iso()))
        base = datetime.now()
        try:
            cur_exp = datetime.fromisoformat(vps['expires_at']) if vps.get('expires_at') else None
            if cur_exp and cur_exp > base:
                base = cur_exp
        except ValueError:
            pass
        new_exp = (base + timedelta(days=vp['period_days'])).isoformat()
        fields = dict(expires_at=new_exp, last_renewed_at=now_iso(), auto_suspend_enabled=1, expiration_days=vp['period_days'])
        reason = (vps.get('suspended_reason') or '').lower()
        if G['is_vps_suspended'](vps) and 'expir' in reason:      # paid for an expired VPS -> bring it back
            fields.update(suspended=0, status='stopped', suspended_reason=None)
        G['update_vps'](vps_id, **fields)
        with db() as c:
            c.execute('UPDATE vps SET renewal_count=COALESCE(renewal_count,0)+1 WHERE id=?', (vps_id,))
        audit(cu.id, 'shop_renew', 'vps', vps_id, {'price': vp['price']})
        notify(cu.id, 'success', 'VPS renewed', 'Valid until %s.' % new_exp[:10])
        return jsonify(success=True, expires_at=new_exp[:16].replace('T', ' '), balance=balance(cu.id))

    @bp.route('/features/api/wallet/redeem', methods=['POST'])
    @api
    def redeem():
        cu = user()
        code = re.sub(r'\s', '', str(body().get('code') or '')).upper()[:40]
        if not code:
            bad('Enter a code')
        with db() as c:
            r = c.execute('SELECT * FROM vf_codes WHERE code=?', (code,)).fetchone()
            if not r or (r['expires_at'] and r['expires_at'] < now_iso()):
                bad('Invalid or expired code', 404)
            if c.execute('SELECT 1 FROM vf_code_uses WHERE code=? AND user_id=?', (code, cu.id)).fetchone():
                bad('You already used this code')
            ok = c.execute('UPDATE vf_codes SET uses=uses+1 WHERE code=? AND uses<max_uses', (code,)).rowcount
            if ok != 1:
                bad('This code has no uses left')
            c.execute('INSERT INTO vf_code_uses(code,user_id,created_at) VALUES(?,?,?)', (code, cu.id, now_iso()))
            after = move(c, cu.id, r['amount'], 'redeem', 'Code %s' % code)
        audit(cu.id, 'wallet_redeem', 'wallet', None, {'amount': r['amount']})
        return jsonify(success=True, added=money(r['amount']), balance=after)

    # ------------------------------ admin
    @bp.route('/admin/shop')
    @admin_page
    def admin_shop():
        with db() as c:
            plans = [dict(r) for r in c.execute('SELECT * FROM vf_plans ORDER BY sort, id')]
            for p in plans:
                p['left'] = _stock_left(c, p)
            orders = [dict(r) for r in c.execute('SELECT o.*, u.username, p.name plan_name FROM vf_orders o LEFT JOIN users u ON u.id=o.user_id '
                                                 'LEFT JOIN vf_plans p ON p.id=o.plan_id ORDER BY o.id DESC LIMIT 40')]
            codes = [dict(r) for r in c.execute('SELECT * FROM vf_codes ORDER BY created_at DESC LIMIT 40')]
            rev = c.execute("SELECT COALESCE(SUM(price),0) FROM vf_orders WHERE status IN ('paid','provisioned')").fetchone()[0]
            held = c.execute('SELECT COALESCE(SUM(balance),0) FROM vf_wallet').fetchone()[0]
        nodes = [{'id': n['id'], 'name': n['name']} for n in G['get_nodes']()]
        return render('features/admin_shop.html', plans=plans, orders=orders, codes=codes, revenue=rev, held=held, nodes=nodes,
                      shop_on=_shop_on())

    @bp.route('/features/api/admin/plans', methods=['POST'])
    @admin_api
    def plan_save():
        d = body()
        name = (d.get('name') or '').strip()[:60]
        if not name:
            bad('Plan needs a name')

        def iv(k, lo, hi):
            try:
                v = int(d.get(k))
            except (TypeError, ValueError):
                bad('%s must be a whole number' % k)
            if not lo <= v <= hi:
                bad('%s must be %d-%d' % (k, lo, hi))
            return v
        vals = (name, (d.get('description') or '').strip()[:300], iv('cpu', 1, 64), iv('ram_gb', 1, 512), iv('disk_gb', 1, 5000),
                to_cents(d.get('price')), iv('period_days', 0, 3650), int(d['node_id']) if d.get('node_id') else None,
                iv('stock', 0, 100000) if str(d.get('stock') or '').strip() != '' else None, iv('bandwidth_gb', 0, 100000) if d.get('bandwidth_gb') not in (None, '') else 0,
                1 if d.get('enabled', True) else 0, iv('sort', 0, 9999) if d.get('sort') not in (None, '') else 0)
        with db() as c:
            if d.get('id'):
                c.execute('UPDATE vf_plans SET name=?,description=?,cpu=?,ram_gb=?,disk_gb=?,price=?,period_days=?,node_id=?,stock=?,bandwidth_gb=?,enabled=?,sort=? WHERE id=?',
                          vals + (int(d['id']),))
            else:
                c.execute('INSERT INTO vf_plans(name,description,cpu,ram_gb,disk_gb,price,period_days,node_id,stock,bandwidth_gb,enabled,sort,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                          vals + (now_iso(),))
        return jsonify(success=True)

    @bp.route('/features/api/admin/plans/<int:pid>', methods=['DELETE'])
    @admin_api
    def plan_delete(pid):
        with db() as c:
            if c.execute('SELECT 1 FROM vf_orders WHERE plan_id=?', (pid,)).fetchone():
                c.execute('UPDATE vf_plans SET enabled=0 WHERE id=?', (pid,))
                return jsonify(success=True, note='Plan has orders, so it was hidden instead of deleted')
            c.execute('DELETE FROM vf_plans WHERE id=?', (pid,))
        return jsonify(success=True)

    @bp.route('/features/api/admin/wallet', methods=['POST'])
    @admin_api
    def admin_wallet():
        d = body()
        ident = (d.get('identifier') or '').strip()
        u = G['User'].get_by_username(ident) or G['User'].get_by_email(ident)
        if not u:
            bad('User not found', 404)
        raw = str(d.get('amount') or '').strip()
        amt = to_cents(raw.lstrip('+-'), allow_zero=False)
        if raw.startswith('-'):
            amt = -amt
        with db() as c:
            after = move(c, u.id, amt, 'admin', ('by %s: %s' % (user().username, d.get('note') or 'manual adjustment')))
        audit(user().id, 'wallet_adjust', 'wallet', u.id, {'amount': amt})
        notify(u.id, 'info', 'Wallet updated', '%s %s. New balance %s.' % ('Added' if amt > 0 else 'Removed', money(abs(amt)), money(after)))
        return jsonify(success=True, balance=money(after))

    @bp.route('/features/api/admin/codes', methods=['POST'])
    @admin_api
    def codes_create():
        d = body()
        amt = to_cents(d.get('amount'), allow_zero=False)
        n = max(1, min(50, int(d.get('count') or 1)))
        uses = max(1, min(10000, int(d.get('max_uses') or 1)))
        days = int(d.get('expires_days') or 0)
        exp = (datetime.now() + timedelta(days=days)).isoformat(timespec='seconds') if days > 0 else None
        out = []
        with db() as c:
            for _ in range(n):
                code = 'TVM-%s-%s' % (secrets.token_hex(2).upper(), secrets.token_hex(2).upper())
                c.execute('INSERT INTO vf_codes(code,amount,max_uses,expires_at,created_by,created_at) VALUES(?,?,?,?,?,?)',
                          (code, amt, uses, exp, user().id, now_iso()))
                out.append(code)
        return jsonify(success=True, codes=out)

    @bp.route('/features/api/admin/codes/<code>', methods=['DELETE'])
    @admin_api
    def codes_delete(code):
        with db() as c:
            c.execute('DELETE FROM vf_codes WHERE code=?', (code,))
        return jsonify(success=True)

    @bp.route('/features/api/admin/orders/<int:oid>/refund', methods=['POST'])
    @admin_api
    def order_refund(oid):
        with db() as c:
            o = c.execute('SELECT * FROM vf_orders WHERE id=?', (oid,)).fetchone()
            if not o or o['status'] not in ('paid', 'provisioned'):
                bad('Order cannot be refunded', 409)
            c.execute("UPDATE vf_orders SET status='refunded' WHERE id=?", (oid,))
            move(c, o['user_id'], o['price'], 'refund', 'Refund of order #%d' % oid)
        notify(o['user_id'], 'info', 'Order refunded', '%s was returned to your wallet.' % money(o['price']))
        audit(user().id, 'shop_refund', 'order', oid)
        return jsonify(success=True)

    @bp.route('/features/api/admin/shop-settings', methods=['POST'])
    @admin_api
    def shop_settings():
        d = body()
        cur = str(d.get('currency') or '$').strip()[:4] or '$'
        G['set_setting']('vf_currency', cur)
        G['set_setting']('vf_shop_enabled', '1' if d.get('enabled', True) else '0')
        return jsonify(success=True)
