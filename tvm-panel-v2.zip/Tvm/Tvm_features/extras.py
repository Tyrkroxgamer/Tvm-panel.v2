"""Extras: manual top-up requests (bank / JazzCash / Easypaisa / crypto ...), announcements, expiry reminders, activity page."""
import json
import re
import threading
import time
from datetime import datetime, timedelta

from flask import jsonify, request

from . import (G, db, bad, body, api, admin_api, page, admin_page, render, now_iso, setting, user, audit, notify,
               alert_user, log)

MAX_PENDING = 3


# ------------------------------------------------------------------------------- expiry reminders
_rem_started = False


def _remind_once():
    """Warn owners 3 days and 1 day before a VPS expires (each warning is sent once per expiry date)."""
    now = datetime.now()
    try:
        vlist = G['get_all_vps']()
    except Exception as e:
        log.debug('reminders: cannot list vps: %s', e)
        return
    for v in vlist:
        exp = v.get('expires_at')
        if not exp or v.get('suspended'):
            continue
        try:
            e = datetime.fromisoformat(str(exp)[:19])
        except ValueError:
            continue
        left = e - now
        if left <= timedelta(0) or left > timedelta(days=3, hours=1):
            continue
        kind = 'd1' if left <= timedelta(days=1, hours=1) else 'd3'
        with db() as c:
            if c.execute('SELECT 1 FROM vf_reminders WHERE vps_id=? AND kind=? AND expires_at=?', (v['id'], kind, exp)).fetchone():
                continue
            c.execute('INSERT OR IGNORE INTO vf_reminders(vps_id,kind,expires_at) VALUES(?,?,?)', (v['id'], kind, exp))
            sold = c.execute('SELECT 1 FROM vf_vps_plan WHERE vps_id=?', (v['id'],)).fetchone()
        name = v.get('hostname') or v.get('container_name')
        hours = max(1, int(left.total_seconds() // 3600))
        when = '%d day(s)' % (hours // 24) if hours >= 24 else '%d hour(s)' % hours
        tip = ' Renew it from the Wallet page to keep it running.' if sold else ''
        alert_user(v['user_id'], 'warning', '%s expires soon' % name, '%s will expire in about %s (%s).%s' % (name, when, str(exp)[:16].replace('T', ' '), tip), color=0xF59E0B)
    with db() as c:                                         # forget old reminder rows
        c.execute('DELETE FROM vf_reminders WHERE expires_at < ?', ((now - timedelta(days=30)).isoformat(),))


def start_reminders():
    global _rem_started
    if _rem_started or G.get('VF_DISABLE_WORKER'):
        return
    _rem_started = True

    def loop():
        time.sleep(60)
        while True:
            try:
                _remind_once()
            except Exception as e:
                log.warning('reminder loop: %s', e)
            time.sleep(1800)
    threading.Thread(target=loop, name='vf-reminders', daemon=True).start()


def register(bp):
    from .shop import move, to_cents, money

    # ------------------------------------------------------------------ announcements
    @bp.route('/features/api/announcements')
    @api
    def ann_list():
        with db() as c:
            rows = c.execute("SELECT id,text,level FROM vf_announcements WHERE active=1 AND (expires_at IS NULL OR expires_at>?) "
                             "ORDER BY id DESC LIMIT 3", (now_iso(),)).fetchall()
        return jsonify(success=True, items=[dict(r) for r in rows])

    @bp.route('/features/api/admin/announcements', methods=['POST'])
    @admin_api
    def ann_add():
        d = body()
        text = str(d.get('text') or '').strip()[:300]
        level = d.get('level') if d.get('level') in ('info', 'success', 'warning', 'danger') else 'info'
        if len(text) < 3:
            bad('Write the announcement text')
        exp = None
        if d.get('days'):
            try:
                exp = (datetime.now() + timedelta(days=max(1, min(365, int(d['days']))))).isoformat(timespec='seconds')
            except (TypeError, ValueError):
                bad('Days must be a number')
        with db() as c:
            aid = c.execute('INSERT INTO vf_announcements(text,level,active,created_at,expires_at) VALUES(?,?,1,?,?)', (text, level, now_iso(), exp)).lastrowid
        audit(user().id, 'announcement_add', 'announcement', aid)
        return jsonify(success=True, id=aid)

    @bp.route('/features/api/admin/announcements/<int:aid>', methods=['DELETE'])
    @admin_api
    def ann_del(aid):
        with db() as c:
            c.execute('DELETE FROM vf_announcements WHERE id=?', (aid,))
        return jsonify(success=True)

    # ------------------------------------------------------------------ manual top-ups
    @bp.route('/features/api/wallet/topup', methods=['POST'])
    @api
    def topup_request():
        cu = user()
        d = body()
        amount = to_cents(d.get('amount'), allow_zero=False)
        try:
            lo = int(setting('vf_topup_min', '100'))
        except ValueError:
            lo = 100
        if amount < lo:
            bad('Minimum top-up is %s' % money(lo))
        method = re.sub(r'\s+', ' ', str(d.get('method') or '')).strip()[:40]
        ref = re.sub(r'\s+', '', str(d.get('reference') or ''))[:60]
        if not method:
            bad('Choose the payment method you used')
        if len(ref) < 4:
            bad('Enter the transaction ID / reference of your payment')
        with db() as c:
            if c.execute("SELECT COUNT(*) FROM vf_topups WHERE user_id=? AND status='pending'", (cu.id,)).fetchone()[0] >= MAX_PENDING:
                bad('You already have %d requests waiting. Please wait for them to be checked.' % MAX_PENDING, 429)
            try:
                tid = c.execute('INSERT INTO vf_topups(user_id,amount,method,reference,note,created_at) VALUES(?,?,?,?,?,?)',
                                (cu.id, amount, method, ref, str(d.get('note') or '')[:200], now_iso())).lastrowid
            except Exception:
                bad('That transaction reference was already submitted')
            admins = [r[0] for r in c.execute('SELECT id FROM users WHERE is_admin=1')]
        for a in admins:
            notify(a, 'info', 'Top-up request #%d' % tid, '%s says they paid %s via %s (ref %s).' % (cu.username, money(amount), method, ref))
        audit(cu.id, 'topup_request', 'topup', tid, {'amount': amount})
        return jsonify(success=True, id=tid)

    @bp.route('/features/api/admin/topups/<int:tid>', methods=['POST'])
    @admin_api
    def topup_decide(tid):
        d = body()
        act = d.get('action')
        if act not in ('approve', 'reject'):
            bad('Invalid action')
        note = str(d.get('note') or '')[:200]
        with db() as c:
            t = c.execute('SELECT * FROM vf_topups WHERE id=?', (tid,)).fetchone()
            if not t:
                bad('Request not found', 404)
            ok = c.execute("UPDATE vf_topups SET status=?, admin_note=?, decided_at=? WHERE id=? AND status='pending'",
                           ('approved' if act == 'approve' else 'rejected', note, now_iso(), tid)).rowcount
            if ok != 1:
                bad('This request was already handled', 409)
            if act == 'approve':
                move(c, t['user_id'], t['amount'], 'topup', 'Top-up #%d (%s %s)' % (tid, t['method'], t['reference']))
        if act == 'approve':
            alert_user(t['user_id'], 'success', 'Top-up approved', '%s was added to your wallet.' % money(t['amount']))
        else:
            alert_user(t['user_id'], 'error', 'Top-up rejected', 'Your top-up #%d was rejected.%s' % (tid, (' Reason: ' + note) if note else ''))
        audit(user().id, 'topup_' + act, 'topup', tid, {'amount': t['amount'], 'user': t['user_id']})
        return jsonify(success=True)

    @bp.route('/features/api/admin/pay-settings', methods=['POST'])
    @admin_api
    def pay_settings():
        d = body()
        G['set_setting']('vf_pay_info', str(d.get('info') or '')[:1500])
        G['set_setting']('vf_topup_min', str(to_cents(d.get('min') or '1', allow_zero=False)))
        return jsonify(success=True)

    @bp.route('/admin/tools')
    @admin_page
    def admin_tools():
        with db() as c:
            topups = [dict(r) for r in c.execute("SELECT t.*, u.username FROM vf_topups t JOIN users u ON u.id=t.user_id "
                                                 "ORDER BY CASE t.status WHEN 'pending' THEN 0 ELSE 1 END, t.id DESC LIMIT 100")]
            anns = [dict(r) for r in c.execute('SELECT * FROM vf_announcements ORDER BY id DESC LIMIT 20')]
        try:
            lo = int(setting('vf_topup_min', '100'))
        except ValueError:
            lo = 100
        return render('features/admin_tools.html', topups=topups, anns=anns, pay_info=setting('vf_pay_info', ''), topup_min=lo)

    # ------------------------------------------------------------------ activity
    @bp.route('/activity')
    @page
    def activity_page():
        cu = user()
        scope = 'all' if (cu.is_admin and request.args.get('all') == '1') else 'mine'
        q = re.sub(r'[^a-zA-Z0-9_ -]', '', request.args.get('q', ''))[:40]
        sql = 'SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON u.id=a.user_id WHERE 1=1'
        args = []
        if scope == 'mine':
            sql += ' AND a.user_id=?'
            args.append(cu.id)
        if q:
            sql += ' AND a.action LIKE ?'
            args.append('%' + q + '%')
        sql += ' ORDER BY a.id DESC LIMIT 150'
        with db() as c:
            rows = [dict(r) for r in c.execute(sql, args)]
        for r in rows:
            try:
                r['details'] = json.dumps(json.loads(r['details']), ensure_ascii=False)[:140] if r.get('details') else ''
            except Exception:
                r['details'] = str(r.get('details') or '')[:140]
        return render('features/activity.html', rows=rows, scope=scope, q=q)
