"""Fleet tools: bulk power actions, tags / groups, one-click apps."""
import base64
import json
import re
import secrets
import shlex
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from flask import jsonify, request

from . import G, db, bad, body, api, page, render, now_iso, setting, user, audit, notify, vps_or_403, log

_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix='vf-bulk')


def _run(coro):
    return G['run_sync'](coro)


# ------------------------------------------------------------------ power (shared with automation)
def power_vps(vps_id, action, actor_id=None, source='manual'):
    """start / stop / restart a VPS the same way the panel's own control route does.
    Returns (ok, message). Safe to call from threads."""
    if action not in ('start', 'stop', 'restart'):
        return False, 'Invalid action'
    vps = G['get_vps_by_id'](int(vps_id))
    if not vps:
        return False, 'VPS not found'
    if G['is_vps_suspended'](vps):
        return False, 'VPS is suspended'
    if vps.get('status') in ('installing', 'reinstalling', 'migrating', 'transferring'):
        return False, 'VPS is busy (%s)' % vps.get('status')
    name, node = vps['container_name'], vps['node_id']
    if action in ('start', 'restart'):
        quota, used = vps.get('bandwidth_quota_gb', 0) or 0, vps.get('bandwidth_used_gb', 0.0) or 0.0
        if quota > 0 and used >= quota:
            return False, 'Bandwidth limit exceeded'
    try:
        ex = G['execute_lxc']
        if action == 'stop':
            _run(ex(name, 'stop %s' % name, node_id=node, operation_type='general'))
            G['update_vps'](vps_id, status='stopped', last_stopped=now_iso())
            new = 'stopped'
        else:
            _run(ex(name, '%s %s' % (action, name), node_id=node, operation_type='start'))
            try:
                _run(G['apply_internal_permissions'](name, node))
                _run(G['recreate_port_forwards'](name))
                if (vps.get('bandwidth_quota_gb', 0) or 0) > 0:
                    _run(G['configure_bandwidth_quota'](name, vps['bandwidth_quota_gb'], node))
            except Exception as e:
                log.warning('post-start steps failed for %s: %s', name, e)
            G['update_vps'](vps_id, status='running', last_started=now_iso())
            new = 'running'
        audit(actor_id, '%s_vps' % action, 'vps', vps_id, {'source': source})
        sio = G.get('socketio')
        if sio:
            try:
                sio.emit('vps_status_change', {'vps_id': vps_id, 'status': new}, room='vps_%s' % vps_id)
            except Exception:
                pass
        return True, new
    except Exception as e:
        return False, str(e)[:300]


# -------------------------------------------------------------------------- bulk jobs
_JOBS = {}
_JOBS_LOCK = threading.Lock()


def _prune_jobs():
    cut = time.time() - 900
    for k in [k for k, v in _JOBS.items() if v['t'] < cut]:
        _JOBS.pop(k, None)


def _accessible(ids):
    cu = user()
    out = []
    for i in dict.fromkeys(int(x) for x in ids):
        v = G['get_vps_by_id'](i)
        if v and (v['user_id'] == cu.id or cu.is_admin):
            out.append(v)
    return out


TAG_RE = re.compile(r'^[\w\- ]{1,20}$', re.UNICODE)


def _clean_tags(tags):
    out = []
    for t in tags or []:
        t = str(t).strip()
        if t and TAG_RE.match(t) and t.lower() not in [x.lower() for x in out]:
            out.append(t)
    return out[:8]


def meta_for(ids):
    if not ids:
        return {}
    q = ','.join('?' * len(ids))
    with db() as c:
        rows = c.execute('SELECT vps_id,tags,grp FROM vf_vps_meta WHERE vps_id IN (%s)' % q, list(ids)).fetchall()
    return {r['vps_id']: {'tags': json.loads(r['tags'] or '[]'), 'group': r['grp'] or ''} for r in rows}


# --------------------------------------------------------------------- one-click apps
def _s(txt):
    return '\n'.join(l[4:] if l.startswith('    ') else l for l in txt.strip('\n').split('\n'))


APPS = {
    'docker': dict(name='Docker', icon='fab fa-docker', desc='Docker Engine + Compose (official installer). Needs "nesting" enabled on the container.',
                   ports='', script=_s('''
    curl -fsSL https://get.docker.com | sh
    systemctl enable --now docker || true
    docker --version''')),
    'nginx': dict(name='Nginx', icon='fas fa-globe', desc='Fast web server on port 80, enabled at boot.', ports='80',
                  script='apt-get install -y nginx\nsystemctl enable --now nginx\nnginx -v'),
    'nodejs': dict(name='Node.js + npm', icon='fab fa-node-js', desc='Node.js runtime with npm and pm2 process manager.', ports='',
                   script='apt-get install -y nodejs npm\nnpm install -g pm2\nnode -v'),
    'python': dict(name='Python 3 toolkit', icon='fab fa-python', desc='python3, pip, venv and build tools.', ports='',
                   script='apt-get install -y python3 python3-pip python3-venv build-essential\npython3 --version'),
    'mariadb': dict(name='MariaDB', icon='fas fa-database', desc='MySQL-compatible database server (local access only).', ports='3306',
                    script='apt-get install -y mariadb-server\nsystemctl enable --now mariadb\nmariadb --version'),
    'wordpress': dict(name='WordPress', icon='fab fa-wordpress', desc='Nginx + PHP-FPM + MariaDB + WordPress. Open the VPS IP in a browser to finish setup.',
                      ports='80', script=_s('''
    apt-get install -y nginx mariadb-server php-fpm php-mysql php-curl php-gd php-xml php-mbstring php-zip curl
    systemctl enable --now mariadb nginx
    DBPASS="$(head -c 18 /dev/urandom | base64 | tr -dc A-Za-z0-9 | head -c 20)"
    mariadb -e "CREATE DATABASE IF NOT EXISTS wordpress CHARACTER SET utf8mb4; CREATE USER IF NOT EXISTS 'wp'@'localhost' IDENTIFIED BY '$DBPASS'; GRANT ALL ON wordpress.* TO 'wp'@'localhost'; FLUSH PRIVILEGES;"
    mkdir -p /var/www/wordpress && cd /tmp && curl -fsSL https://wordpress.org/latest.tar.gz | tar xz
    cp -r /tmp/wordpress/. /var/www/wordpress/ && cp /var/www/wordpress/wp-config-sample.php /var/www/wordpress/wp-config.php
    sed -i "s/database_name_here/wordpress/;s/username_here/wp/;s/password_here/$DBPASS/" /var/www/wordpress/wp-config.php
    chown -R www-data:www-data /var/www/wordpress
    PHPSOCK="$(ls /run/php/php*-fpm.sock | head -1)"
    cat > /etc/nginx/sites-available/wordpress <<EOF
    server { listen 80 default_server; root /var/www/wordpress; index index.php;
      location / { try_files \\$uri \\$uri/ /index.php?\\$args; }
      location ~ \\.php\\$ { include snippets/fastcgi-php.conf; fastcgi_pass unix:$PHPSOCK; } }
    EOF
    rm -f /etc/nginx/sites-enabled/default && ln -sf /etc/nginx/sites-available/wordpress /etc/nginx/sites-enabled/wordpress
    nginx -t && systemctl reload nginx
    echo "WordPress ready. DB: wordpress  user: wp  password: $DBPASS"''')),
    'codeserver': dict(name='code-server (VS Code)', icon='fas fa-code', desc='VS Code in the browser on port 8080, password protected.', ports='8080',
                       script=_s('''
    curl -fsSL https://code-server.dev/install.sh | sh
    PASS="$(head -c 18 /dev/urandom | base64 | tr -dc A-Za-z0-9 | head -c 16)"
    mkdir -p /root/.config/code-server
    printf 'bind-addr: 0.0.0.0:8080\\nauth: password\\npassword: %s\\ncert: false\\n' "$PASS" > /root/.config/code-server/config.yaml
    systemctl enable --now code-server@root
    echo "code-server ready on port 8080. Password: $PASS"''')),
    'fail2ban': dict(name='Security basics', icon='fas fa-shield-halved', desc='fail2ban for SSH brute-force protection + automatic security updates.', ports='',
                     script=_s('''
    apt-get install -y fail2ban unattended-upgrades
    systemctl enable --now fail2ban
    echo "fail2ban active"''')),
}
APP_ORDER = ['docker', 'nginx', 'nodejs', 'python', 'mariadb', 'wordpress', 'codeserver', 'fail2ban']

_WRAP = '''#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
rm -f /var/lib/vf_app.rc
(
set -e
apt-get update -y
%s
) > /var/log/vf_app.log 2>&1
echo $? > /var/lib/vf_app.rc
'''


def _install_thread(job_id, vps, app_id):
    a = APPS[app_id]
    name, node = vps['container_name'], vps['node_id']
    ex = G['execute_lxc']

    def setlog(status=None, text=None):
        with db() as c:
            if text is not None:
                c.execute('UPDATE vf_app_jobs SET log=? WHERE id=?', (text[-6000:], job_id))
            if status:
                c.execute('UPDATE vf_app_jobs SET status=?, finished_at=? WHERE id=?', (status, now_iso(), job_id))

    try:
        script = _WRAP % a['script']
        b64 = base64.b64encode(script.encode()).decode()
        _run(ex(name, "exec %s -- sh -c %s" % (name, shlex.quote("echo %s | base64 -d > /tmp/vf_app.sh && chmod +x /tmp/vf_app.sh" % b64)),
                node_id=node, operation_type='config'))
        _run(ex(name, "exec %s -- sh -c %s" % (name, shlex.quote("nohup bash /tmp/vf_app.sh >/dev/null 2>&1 &")),
                node_id=node, operation_type='config'))
        deadline = time.time() + 25 * 60
        while time.time() < deadline:
            time.sleep(6)
            try:
                out = _run(ex(name, "exec %s -- sh -c %s" % (name, shlex.quote("tail -n 25 /var/log/vf_app.log 2>/dev/null; echo '@@RC:'$(cat /var/lib/vf_app.rc 2>/dev/null)")),
                              node_id=node, operation_type='stats'))
            except Exception as e:
                setlog(text='waiting for container... (%s)' % str(e)[:100])
                continue
            out = out if isinstance(out, str) else ''
            body_txt, _, rc = out.rpartition('@@RC:')
            setlog(text=body_txt.strip())
            rc = rc.strip()
            if rc != '':
                if rc == '0':
                    setlog('done')
                    notify(vps['user_id'], 'success', '%s installed' % a['name'], 'Finished on %s.' % name)
                else:
                    setlog('failed')
                    notify(vps['user_id'], 'error', '%s install failed' % a['name'], 'See the log on the Apps page (%s).' % name)
                return
        setlog('failed', 'Timed out after 25 minutes.')
    except Exception as e:
        setlog('failed', 'Error: %s' % e)


# ----------------------------------------------------------------------------------- routes
def register(bp):
    @bp.route('/features/api/meta')
    @api
    def meta_get():
        ids = [int(x) for x in re.findall(r'\d+', request.args.get('ids', ''))][:300]
        ok = [v['id'] for v in _accessible(ids)]
        return jsonify(success=True, meta=meta_for(ok))

    @bp.route('/features/api/meta', methods=['POST'])
    @api
    def meta_set():
        d = body()
        vps = _accessible(d.get('vps_ids') or [])
        if not vps:
            bad('Select at least one VPS')
        add, rem = _clean_tags(d.get('add_tags')), {t.lower() for t in _clean_tags(d.get('remove_tags'))}
        replace = _clean_tags(d['set_tags']) if d.get('set_tags') is not None else None
        group = d.get('group')
        if group is not None:
            group = str(group).strip()[:32]
        with db() as c:
            for v in vps:
                r = c.execute('SELECT tags,grp FROM vf_vps_meta WHERE vps_id=?', (v['id'],)).fetchone()
                tags = json.loads(r['tags'] or '[]') if r else []
                grp = (r['grp'] if r else '') or ''
                if replace is not None:
                    tags = replace
                tags = [t for t in tags if t.lower() not in rem]
                for t in add:
                    if t.lower() not in [x.lower() for x in tags]:
                        tags.append(t)
                tags = tags[:8]
                if group is not None:
                    grp = group
                c.execute('INSERT INTO vf_vps_meta(vps_id,tags,grp) VALUES(?,?,?) ON CONFLICT(vps_id) DO UPDATE SET tags=excluded.tags, grp=excluded.grp',
                          (v['id'], json.dumps(tags), grp))
        return jsonify(success=True, meta=meta_for([v['id'] for v in vps]))

    @bp.route('/features/api/bulk', methods=['POST'])
    @api
    def bulk_start():
        d = body()
        action = d.get('action')
        if action not in ('start', 'stop', 'restart'):
            bad('Action must be start, stop or restart')
        vps = _accessible(d.get('vps_ids') or [])
        if not vps:
            bad('Select at least one VPS')
        if len(vps) > 40:
            bad('At most 40 VPS at once')
        cu = user()
        actor_id, owner_id = cu.id, cu.id          # plain ints: `current_user` is a request-bound proxy, unusable in threads
        job = uuid.uuid4().hex[:12]
        with _JOBS_LOCK:
            _prune_jobs()
            _JOBS[job] = {'t': time.time(), 'user': owner_id, 'action': action, 'done': False,
                          'items': {v['id']: {'name': v.get('hostname') or v['container_name'], 'state': 'queued', 'msg': ''} for v in vps}}

        def work(v):
            _JOBS[job]['items'][v['id']]['state'] = 'running'
            try:
                ok, msg = power_vps(v['id'], action, actor_id, 'bulk')
            except Exception as e:
                ok, msg = False, str(e)[:200]
            _JOBS[job]['items'][v['id']].update(state='ok' if ok else 'failed', msg=msg)

        futs = [_POOL.submit(work, v) for v in vps]

        def closer():
            for f in futs:
                try:
                    f.result()
                except Exception:
                    pass
            _JOBS[job]['done'] = True
        threading.Thread(target=closer, daemon=True).start()
        return jsonify(success=True, job=job)

    @bp.route('/features/api/bulk/<job>')
    @api
    def bulk_status(job):
        j = _JOBS.get(job)
        if not j or j['user'] != user().id:
            bad('Job not found', 404)
        return jsonify(success=True, done=j['done'], items=[dict(id=k, **v) for k, v in j['items'].items()])

    # ---- one-click apps ----
    @bp.route('/features/apps')
    @page
    def apps_page():
        cu = user()
        mine = G['get_all_vps']() if cu.is_admin else G['get_vps_for_user'](cu.id)
        vl = [{'id': v['id'], 'name': v.get('hostname') or v['container_name'], 'status': v.get('status'), 'os': v.get('os_version', '')}
               for v in mine if not G['is_vps_suspended'](v)]
        apps = [dict(id=k, **{x: APPS[k][x] for x in ('name', 'icon', 'desc', 'ports')}) for k in APP_ORDER]
        with db() as c:
            ids = [v['id'] for v in vl] or [0]
            jobs = [dict(r) for r in c.execute('SELECT id,vps_id,app,status,created_at FROM vf_app_jobs WHERE vps_id IN (%s) ORDER BY id DESC LIMIT 15'
                                                % ','.join('?' * len(ids)), ids)]
        for j in jobs:
            j['app_name'] = APPS.get(j['app'], {}).get('name', j['app'])
        return render('features/apps.html', vps_list=vl, apps=apps, jobs=jobs, selected=request.args.get('vps', type=int))

    @bp.route('/features/api/apps/install', methods=['POST'])
    @api
    def apps_install():
        d = body()
        app_id = d.get('app')
        if app_id not in APPS:
            bad('Unknown app')
        vps = vps_or_403(d.get('vps_id'))
        if G['is_vps_suspended'](vps):
            bad('VPS is suspended')
        osv = (vps.get('os_version') or '').lower()
        if not any(x in osv for x in ('ubuntu', 'debian')):
            bad('One-click apps support Ubuntu and Debian VPS only (this one is %s)' % (vps.get('os_version') or 'unknown'))
        if vps.get('status') != 'running':
            bad('Start the VPS first')
        with db() as c:
            if c.execute("SELECT 1 FROM vf_app_jobs WHERE vps_id=? AND status='running'", (vps['id'],)).fetchone():
                bad('Another install is still running on this VPS')
            cur = c.execute('INSERT INTO vf_app_jobs(vps_id,user_id,app,status,created_at) VALUES(?,?,?,?,?)',
                            (vps['id'], user().id, app_id, 'running', now_iso()))
            job_id = cur.lastrowid
        audit(user().id, 'install_app', 'vps', vps['id'], {'app': app_id})
        threading.Thread(target=_install_thread, args=(job_id, vps, app_id), daemon=True).start()
        return jsonify(success=True, job=job_id)

    @bp.route('/features/api/apps/job/<int:job_id>')
    @api
    def apps_job(job_id):
        with db() as c:
            r = c.execute('SELECT * FROM vf_app_jobs WHERE id=?', (job_id,)).fetchone()
        if not r or (r['user_id'] != user().id and not user().is_admin):
            bad('Job not found', 404)
        return jsonify(success=True, status=r['status'], log=r['log'] or '')
