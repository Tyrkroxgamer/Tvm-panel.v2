"""avm_features - extra panel features kept OUT of the 850 KB avm.py.

Security (real TOTP 2FA, login history, API keys UI) | Fleet (bulk actions, tags/groups,
one-click apps) | Automation (alerts, auto-restart, schedules) | Insights (usage + uptime history)
| Shop (plans, wallet, redeem codes).

Hook (already added to avm.py, right before the __main__ block):

    import avm_features; avm_features.init(app, globals())

Everything here talks to the panel only through the namespace passed to init(), so this
package never imports avm (which would re-import the module when it is run as __main__).
"""
import json
import logging
import re
import threading
from datetime import datetime
from functools import wraps

from flask import Blueprint, jsonify, redirect, render_template, request, url_for, flash

log = logging.getLogger('avm_features')

G = {}                      # panel namespace (set in init)
bp = Blueprint('vf', __name__)
_started = False
_lock = threading.Lock()


# ----------------------------------------------------------------- tiny helpers
def db():
    """Panel's get_db() context manager (commits on exit, rolls back on error)."""
    return G['get_db']()


def now_iso():
    return datetime.now().isoformat(timespec='seconds')


def setting(key, default=''):
    try:
        v = G['get_setting'](key, default)
        return default if v is None else v
    except Exception:
        return default


def user():
    return G['current_user']


def render(tpl, **kw):
    kw.setdefault('panel_name', setting('site_name', 'tvm-panel'))
    kw.setdefault('currency', setting('vf_currency', '$'))
    return render_template(tpl, **kw)


def notify(user_id, kind, title, message):
    try:
        G['create_notification'](user_id, kind, title, message)
    except Exception as e:                                   # never break a feature for a bell
        log.debug('notify failed: %s', e)


def audit(user_id, action, resource=None, rid=None, details=None):
    try:
        G['log_activity'](user_id, action, resource, None if rid is None else str(rid), details)
    except Exception:
        pass


def api(f):
    """Login required + JSON in/out. Mutations must be JSON (cheap CSRF defence: a cross-site
    <form> cannot send application/json without a CORS preflight)."""
    @wraps(f)
    def wrapper(*a, **kw):
        cu = user()
        if not cu.is_authenticated:
            return jsonify(success=False, error='Login required'), 401
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE') and not request.is_json:
            return jsonify(success=False, error='JSON body required'), 415
        try:
            return f(*a, **kw)
        except _Bad as e:
            return jsonify(success=False, error=str(e)), e.code
        except Exception as e:
            log.exception('api error in %s', f.__name__)
            return jsonify(success=False, error='Internal error: %s' % e), 500
    return wrapper


def page(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not user().is_authenticated:
            return redirect(url_for('login', next=request.path))
        return f(*a, **kw)
    return wrapper


def admin_page(f):
    @wraps(f)
    def wrapper(*a, **kw):
        cu = user()
        if not cu.is_authenticated:
            return redirect(url_for('login', next=request.path))
        if not cu.is_admin:
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*a, **kw)
    return wrapper


def admin_api(f):
    @wraps(f)
    @api
    def wrapper(*a, **kw):
        if not user().is_admin:
            return jsonify(success=False, error='Admin access required'), 403
        return f(*a, **kw)
    return wrapper


class _Bad(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


def bad(msg, code=400):
    raise _Bad(msg, code)


def body():
    return request.get_json(silent=True) or {}


def vps_or_403(vps_id, need_running=False):
    """VPS row the current user may control (owner or admin)."""
    vps = G['get_vps_by_id'](int(vps_id))
    cu = user()
    if not vps or (vps['user_id'] != cu.id and not cu.is_admin):
        bad('VPS not found or access denied', 404)
    return vps


# ------------------------------------------------------------------- Discord
_DISCORD_HOSTS = ('discord.com', 'discordapp.com', 'ptb.discord.com', 'canary.discord.com')


def valid_webhook(url):
    from urllib.parse import urlparse
    try:
        u = urlparse(url or '')
    except Exception:
        return False
    return u.scheme == 'https' and (u.hostname or '') in _DISCORD_HOSTS and u.path.startswith('/api/webhooks/') and len(url) < 400


def send_discord(webhook, title, description, color=0x38BDF8, fields=None):
    """Post an embed to a Discord webhook. Returns True/False, never raises."""
    if not valid_webhook(webhook):
        return False
    try:
        import requests
        embed = {'title': str(title)[:250], 'description': str(description)[:1800], 'color': color,
                 'timestamp': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
                 'footer': {'text': setting('site_name', 'tvm-panel')}}
        if fields:
            embed['fields'] = [{'name': str(k)[:200], 'value': str(v)[:900], 'inline': True} for k, v in fields][:10]
        r = requests.post(webhook, json={'embeds': [embed], 'username': setting('site_name', 'tvm-panel')[:80]}, timeout=8)
        return r.status_code < 300
    except Exception as e:
        log.warning('discord webhook failed: %s', e)
        return False


def user_webhook(user_id):
    with db() as c:
        r = c.execute('SELECT discord_webhook FROM vf_user_prefs WHERE user_id=?', (user_id,)).fetchone()
    return r[0] if r and r[0] else ''


def alert_user(user_id, kind, title, message, color=0x38BDF8, fields=None, panel=True):
    """Panel notification + Discord webhook (if the user set one)."""
    if panel:
        notify(user_id, kind, title, message)
    hook = user_webhook(user_id)
    if hook:
        threading.Thread(target=send_discord, args=(hook, title, message, color, fields), daemon=True).start()


@bp.route('/manifest.webmanifest')
def web_manifest():
    name = setting('site_name', 'tvm-panel')
    return jsonify({'name': name, 'short_name': name[:12], 'start_url': '/', 'scope': '/', 'display': 'standalone',
                    'background_color': '#050b16', 'theme_color': '#0ea5e9',
                    'icons': [{'src': '/static/img/icon.svg', 'sizes': 'any', 'type': 'image/svg+xml', 'purpose': 'any'}]}), 200, \
        {'Content-Type': 'application/manifest+json', 'Cache-Control': 'public, max-age=3600'}


# -------------------------------------------------------------------- schema
SCHEMA = """
CREATE TABLE IF NOT EXISTS vf_user_prefs(
    user_id INTEGER PRIMARY KEY, discord_webhook TEXT, login_alerts INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS vf_login_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, ip TEXT, user_agent TEXT, method TEXT,
    success INTEGER DEFAULT 1, new_device INTEGER DEFAULT 0, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_lh_user ON vf_login_history(user_id, id);
CREATE INDEX IF NOT EXISTS idx_vf_lh_ip ON vf_login_history(ip, created_at);
CREATE TABLE IF NOT EXISTS vf_2fa(
    user_id INTEGER PRIMARY KEY, pending_secret TEXT, recovery TEXT DEFAULT '[]', last_counter INTEGER DEFAULT 0,
    enabled_at TEXT);
CREATE TABLE IF NOT EXISTS vf_vps_meta(
    vps_id INTEGER PRIMARY KEY, tags TEXT DEFAULT '[]', grp TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS vf_app_jobs(
    id INTEGER PRIMARY KEY AUTOINCREMENT, vps_id INTEGER NOT NULL, user_id INTEGER NOT NULL, app TEXT NOT NULL,
    status TEXT DEFAULT 'running', log TEXT DEFAULT '', created_at TEXT NOT NULL, finished_at TEXT);
CREATE TABLE IF NOT EXISTS vf_alert_rules(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, vps_id INTEGER, scope TEXT DEFAULT 'mine',
    metric TEXT NOT NULL, threshold REAL DEFAULT 90, duration_min INTEGER DEFAULT 3, action TEXT DEFAULT 'none',
    notify_discord INTEGER DEFAULT 1, notify_panel INTEGER DEFAULT 1, cooldown_min INTEGER DEFAULT 30,
    enabled INTEGER DEFAULT 1, created_at TEXT NOT NULL, last_fired TEXT);
CREATE TABLE IF NOT EXISTS vf_alert_events(
    id INTEGER PRIMARY KEY AUTOINCREMENT, rule_id INTEGER, vps_id INTEGER, user_id INTEGER, metric TEXT, value REAL,
    action TEXT, message TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_ae ON vf_alert_events(user_id, id);
CREATE TABLE IF NOT EXISTS vf_schedules(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, vps_id INTEGER NOT NULL, action TEXT NOT NULL,
    at_time TEXT NOT NULL, days TEXT DEFAULT '0,1,2,3,4,5,6', tz_offset INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1,
    last_run TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vf_samples(
    vps_id INTEGER NOT NULL, ts INTEGER NOT NULL, cpu REAL, ram REAL, disk REAL, up INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS idx_vf_samples ON vf_samples(vps_id, ts);
CREATE TABLE IF NOT EXISTS vf_wallet(
    user_id INTEGER PRIMARY KEY, balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0));
CREATE TABLE IF NOT EXISTS vf_wallet_tx(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, amount INTEGER NOT NULL, kind TEXT NOT NULL,
    note TEXT, balance_after INTEGER, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_tx ON vf_wallet_tx(user_id, id);
CREATE TABLE IF NOT EXISTS vf_plans(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '', cpu INTEGER NOT NULL,
    ram_gb INTEGER NOT NULL, disk_gb INTEGER NOT NULL, price INTEGER NOT NULL, period_days INTEGER DEFAULT 30,
    node_id INTEGER, stock INTEGER, bandwidth_gb INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1, sort INTEGER DEFAULT 0,
    created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vf_orders(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, plan_id INTEGER NOT NULL, vps_id INTEGER,
    price INTEGER NOT NULL, kind TEXT DEFAULT 'new', status TEXT DEFAULT 'paid', hostname TEXT, note TEXT,
    created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_orders ON vf_orders(user_id, id);
CREATE TABLE IF NOT EXISTS vf_vps_plan(vps_id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL, price INTEGER NOT NULL,
    period_days INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS vf_codes(
    code TEXT PRIMARY KEY, amount INTEGER NOT NULL, max_uses INTEGER DEFAULT 1, uses INTEGER DEFAULT 0,
    expires_at TEXT, created_by INTEGER, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vf_code_uses(code TEXT NOT NULL, user_id INTEGER NOT NULL, created_at TEXT NOT NULL,
    PRIMARY KEY(code, user_id));
CREATE TABLE IF NOT EXISTS vf_teams(
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, owner_id INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vf_team_members(
    team_id INTEGER NOT NULL, user_id INTEGER NOT NULL, added_at TEXT NOT NULL, PRIMARY KEY(team_id, user_id));
CREATE TABLE IF NOT EXISTS vf_team_vps(
    team_id INTEGER NOT NULL, vps_id INTEGER NOT NULL, added_by INTEGER, PRIMARY KEY(team_id, vps_id));
CREATE TABLE IF NOT EXISTS vf_team_share(
    vps_id INTEGER NOT NULL, user_id INTEGER NOT NULL, team_id INTEGER NOT NULL, added INTEGER DEFAULT 1,
    PRIMARY KEY(vps_id, user_id, team_id));
CREATE TABLE IF NOT EXISTS vf_snippets(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, command TEXT NOT NULL,
    created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vf_cmd_runs(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, command TEXT NOT NULL, results TEXT DEFAULT '{}',
    status TEXT DEFAULT 'running', created_at TEXT NOT NULL, finished_at TEXT);
CREATE TABLE IF NOT EXISTS vf_tickets(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, subject TEXT NOT NULL, category TEXT DEFAULT 'general',
    priority TEXT DEFAULT 'normal', status TEXT DEFAULT 'open', vps_id INTEGER, created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_tk ON vf_tickets(user_id, id);
CREATE INDEX IF NOT EXISTS idx_vf_tk_st ON vf_tickets(status, updated_at);
CREATE TABLE IF NOT EXISTS vf_ticket_msgs(
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, user_id INTEGER NOT NULL, is_staff INTEGER DEFAULT 0,
    body TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_vf_tm ON vf_ticket_msgs(ticket_id, id);
CREATE TABLE IF NOT EXISTS vf_ref_codes(user_id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS vf_referrals(
    referred_id INTEGER PRIMARY KEY, referrer_id INTEGER NOT NULL, status TEXT DEFAULT 'pending',
    reward_referrer INTEGER DEFAULT 0, reward_referred INTEGER DEFAULT 0, created_at TEXT NOT NULL, rewarded_at TEXT);
CREATE INDEX IF NOT EXISTS idx_vf_ref ON vf_referrals(referrer_id);
CREATE TABLE IF NOT EXISTS vf_announcements(
    id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, level TEXT DEFAULT 'info', active INTEGER DEFAULT 1,
    created_at TEXT NOT NULL, expires_at TEXT);
CREATE TABLE IF NOT EXISTS vf_topups(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, amount INTEGER NOT NULL, method TEXT, reference TEXT,
    note TEXT, status TEXT DEFAULT 'pending', admin_note TEXT, created_at TEXT NOT NULL, decided_at TEXT);
CREATE INDEX IF NOT EXISTS idx_vf_topups ON vf_topups(status, id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_vf_topups_ref ON vf_topups(lower(method), lower(reference)) WHERE status IN ('pending','approved');
CREATE TABLE IF NOT EXISTS vf_reminders(
    vps_id INTEGER NOT NULL, kind TEXT NOT NULL, expires_at TEXT NOT NULL, PRIMARY KEY(vps_id, kind, expires_at));
"""


def init_schema():
    with db() as c:
        c.executescript(SCHEMA)


# ----------------------------------------------------------------------- init
def init(app, namespace):
    """Register the blueprint, create tables, patch the 2FA route and start the worker."""
    global _started
    with _lock:
        if _started:
            return
        _started = True
    G.clear()
    G.update(namespace)
    init_schema()

    from . import security, fleet, automation, shop, teams, runner, support, referrals, admindash, extras
    security.register(bp)
    fleet.register(bp)
    automation.register(bp)
    shop.register(bp)
    teams.register(bp)
    runner.register(bp)
    support.register(bp)
    referrals.register(bp)
    admindash.register(bp)
    extras.register(bp)
    referrals.install_hooks(app)
    app.register_blueprint(bp)
    security.install_hooks(app)           # 2FA fix, login history, brute-force guard, API key scopes
    automation.start_worker(app)
    extras.start_reminders()
    try:
        app.jinja_env.globals['vf_enabled'] = True
        app.jinja_env.globals['vf_shop_enabled'] = lambda: setting('vf_shop_enabled', '1') == '1'
    except Exception:
        pass
    log.info('avm_features ready (security, fleet, automation, insights, shop, teams, runner, support, referrals, admin dashboard)')
