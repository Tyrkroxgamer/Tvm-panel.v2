"""Command runner: run a shell command (or a saved snippet) on one or many of your running VPS and read the output.

The panel already has an SSH console and a file manager. This is the quick, phone-friendly alternative: no terminal
emulator, just "run this on these servers". Owner/admin only (a shared member never gets root command execution here).
"""
import json
import shlex
import threading
import time
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor

from flask import jsonify

from . import G, db, bad, body, api, page, render, now_iso, user, audit, log

_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix='vf-run')
MAX_TARGETS = 15
MAX_CMD = 2000
OUT_CAP = 8000
_res_lock = threading.Lock()


def _exec_one(vps, command):
    name, node = vps['container_name'], vps['node_id']
    t0 = time.time()
    try:
        out = G['run_sync'](G['execute_lxc'](
            name, 'exec %s -- sh -c %s' % (name, shlex.quote(command)), timeout=60, node_id=node, operation_type='config'))
        out = out if isinstance(out, str) else str(out or '')
        return dict(ok=True, out=out[-OUT_CAP:], secs=round(time.time() - t0, 1))
    except Exception as e:
        return dict(ok=False, out=str(e)[-OUT_CAP:], secs=round(time.time() - t0, 1))


def _worker(run_id, targets, command):
    def one(v):
        r = _exec_one(v, command)
        r['name'] = v.get('hostname') or v['container_name']
        with _res_lock, db() as c:
            row = c.execute('SELECT results FROM vf_cmd_runs WHERE id=?', (run_id,)).fetchone()
            cur = json.loads(row[0] or '{}')
            cur[str(v['id'])] = r
            c.execute('UPDATE vf_cmd_runs SET results=? WHERE id=?', (json.dumps(cur), run_id))
    try:
        list(_POOL.map(one, targets))
    except Exception as e:
        log.warning('runner worker failed: %s', e)
    finally:
        with db() as c:
            c.execute("UPDATE vf_cmd_runs SET status='done', finished_at=? WHERE id=?", (now_iso(), run_id))


def register(bp):
    @bp.route('/tools')
    @page
    def tools_page():
        cu = user()
        vps = [dict(id=v['id'], name=v.get('hostname') or v['container_name'], status=v.get('status'))
               for v in G['get_vps_for_user'](cu.id)]
        return render('features/runner.html', vps_list=vps)

    @bp.route('/features/api/snippets')
    @api
    def snippets_list():
        with db() as c:
            rows = c.execute('SELECT id,name,command FROM vf_snippets WHERE user_id=? ORDER BY name', (user().id,)).fetchall()
        return jsonify(success=True, snippets=[dict(r) for r in rows])

    @bp.route('/features/api/snippets', methods=['POST'])
    @api
    def snippets_add():
        d = body()
        name, cmd = str(d.get('name') or '').strip()[:40], str(d.get('command') or '').strip()
        if not name or not cmd:
            bad('Name and command are required')
        if len(cmd) > MAX_CMD:
            bad('Command is too long (max %d characters)' % MAX_CMD)
        with db() as c:
            if c.execute('SELECT COUNT(*) FROM vf_snippets WHERE user_id=?', (user().id,)).fetchone()[0] >= 50:
                bad('You can save up to 50 snippets')
            sid = c.execute('INSERT INTO vf_snippets(user_id,name,command,created_at) VALUES(?,?,?,?)',
                            (user().id, name, cmd, now_iso())).lastrowid
        return jsonify(success=True, id=sid)

    @bp.route('/features/api/snippets/<int:sid>', methods=['DELETE'])
    @api
    def snippets_del(sid):
        with db() as c:
            c.execute('DELETE FROM vf_snippets WHERE id=? AND user_id=?', (sid, user().id))
        return jsonify(success=True)

    @bp.route('/features/api/run', methods=['POST'])
    @api
    def run_start():
        cu = user()
        d = body()
        command = str(d.get('command') or '').strip()
        if not command:
            bad('Type a command')
        if len(command) > MAX_CMD:
            bad('Command is too long (max %d characters)' % MAX_CMD)
        ids = []
        for x in (d.get('vps_ids') or []):
            try:
                ids.append(int(x))
            except (TypeError, ValueError):
                pass
        ids = list(dict.fromkeys(ids))[:MAX_TARGETS]
        if not ids:
            bad('Pick at least one server')
        with db() as c:
            cutoff = (datetime.now() - timedelta(minutes=10)).isoformat(timespec='seconds')
            if c.execute("SELECT COUNT(*) FROM vf_cmd_runs WHERE user_id=? AND status='running' AND created_at>?", (cu.id, cutoff)).fetchone()[0] >= 2:
                bad('Two runs are already in progress, wait for them to finish', 429)
        targets, skipped = [], {}
        for i in ids:
            v = G['get_vps_by_id'](i)
            if not v or (v['user_id'] != cu.id and not cu.is_admin):
                skipped[str(i)] = dict(name='#%d' % i, ok=False, out='Not found or access denied', secs=0)
            elif G['is_vps_suspended'](v):
                skipped[str(i)] = dict(name=v.get('hostname') or v['container_name'], ok=False, out='VPS is suspended', secs=0)
            elif v.get('status') != 'running':
                skipped[str(i)] = dict(name=v.get('hostname') or v['container_name'], ok=False, out='VPS is not running', secs=0)
            else:
                targets.append(v)
        with db() as c:
            run_id = c.execute('INSERT INTO vf_cmd_runs(user_id,command,results,status,created_at) VALUES(?,?,?,?,?)',
                               (cu.id, command, json.dumps(skipped), 'running' if targets else 'done', now_iso())).lastrowid
        audit(cu.id, 'command_run', 'vps', ','.join(str(t['id']) for t in targets), {'command': command[:200]})
        if targets:
            threading.Thread(target=_worker, args=(run_id, targets, command), daemon=True).start()
        return jsonify(success=True, run=run_id)

    @bp.route('/features/api/run/<int:run_id>')
    @api
    def run_get(run_id):
        with db() as c:
            r = c.execute('SELECT * FROM vf_cmd_runs WHERE id=?', (run_id,)).fetchone()
        if not r or (r['user_id'] != user().id and not user().is_admin):
            bad('Run not found', 404)
        return jsonify(success=True, status=r['status'], command=r['command'], results=json.loads(r['results'] or '{}'))

    @bp.route('/features/api/runs')
    @api
    def run_history():
        with db() as c:
            rows = c.execute('SELECT id,command,status,created_at FROM vf_cmd_runs WHERE user_id=? ORDER BY id DESC LIMIT 15',
                             (user().id,)).fetchall()
        return jsonify(success=True, runs=[dict(r) for r in rows])
